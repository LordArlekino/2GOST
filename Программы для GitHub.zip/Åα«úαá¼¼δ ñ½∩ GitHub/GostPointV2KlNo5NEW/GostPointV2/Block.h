#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

class Block256
{
public:
	unsigned __int32 A[8];
	Block256();
	void Clear();
	void Print();
	//void P();
	//void S();
	//void L();

	void rnd();
	void InverseBit(unsigned int num);

	//unsigned int r();

	//bool IsSoglas(Block64 y);


	//void PrintRazChar(Block64 y, FILE *p);

	//Block64 operator^(Block64 v__);
	//Block64 operator=(Block64 v__);

	//unsigned int wtMatr();

	unsigned int GetBitFromBlock(unsigned int num);


	//friend unsigned int getbit(unsigned int a, unsigned int pos);
};

Block256::Block256()
{
	A[0] = 0;
	A[1] = 0;
	A[2] = 0;
	A[3] = 0;
	A[4] = 0;
	A[5] = 0;
	A[6] = 0;
	A[7] = 0;
	

}

void Block256::Clear()
{
	A[0] = 0;
	A[1] = 0;
	A[2] = 0;
	A[3] = 0;
	A[4] = 0;
	A[5] = 0;
	A[6] = 0;
	A[7] = 0;
}

unsigned int RangedRandDemo()
{
	// Generate random numbers in the half-closed interval
	// [range_min, range_max). In other words,
	// range_min <= random number < range_max
	unsigned int rez = 0, r1,r2;
	
	int range_min, range_max;

	range_min = 0;
	range_max = RAND_MAX;

	r1 = (double)rand() / (RAND_MAX + 1) * (range_max - range_min) + range_min;
	r2 = (double)rand() / (RAND_MAX + 1) * (range_max - range_min) + range_min;

	rez = ((r1 & 0xffff) << 16) ^ (r2 & 0xffff);

	return rez;
}

void Block256::rnd()
{
	int i = 0;

	for (i = 0; i < 8; i++)
		{
			A[i] = RangedRandDemo();
		}
}

void Block256::InverseBit(unsigned int num)
{
	//Block256 tmp;
	unsigned int q, r, e = 1;

	q = num / 32;
	r = num % 32;

	A[q] = A[q] ^ (e << r);

}


void Block256::Print()
{
	/*int i = 0, j = 0, bl[4][4];

	for (i = 0; i<4; i++)
	{
		for (j = 0; j<4; j++)
		{
			bl[i][j] = (A[i] >> 4 * j) & 0xf;
		}
	}


	for (i = 0; i<4; i++)
	{
		for (j = 0; j<4; j++)
		{
			printf("%x ", bl[3 - i][3 - j]);
		}
	}

	printf("\n");*/

	printf("%x %x %x %x %x %x %x %x\n",A[7],A[6],A[5],A[4],A[3],A[2],A[1],A[0]);

}


unsigned int getbit(unsigned int a, unsigned int pos) {
	a >>= pos;
	return(a & 1);
}

unsigned int Block256::GetBitFromBlock(unsigned int num)
{
	int q, r, e = 1;
	unsigned int rez = 0;

	q = num / 32;
	r = num % 32;


	rez = getbit(A[q], r);

	return rez;
}






//void Block64::P()
//{
//	//Block64 rez;
//
//
//	int i = 0, j = 0, bl[4][4], box[16], box2[16];
//
//	for (i = 0; i<4; i++)
//	{
//		for (j = 0; j<4; j++)
//		{
//			bl[i][j] = (A[i] >> 4 * j) & 0xf;
//			box[4 * i + j] = bl[i][j];
//		}
//	}
//
//
//
//
//	//��������� ������������
//	for (i = 0; i<16; i++)
//	{
//		box2[tau1[i]] = box[i];
//	}
//
//
//
//	//rez.Clear();
//
//
//
//	for (i = 0; i<4; i++)
//	{
//		A[i] = 0;
//		for (j = 0; j<4; j++)
//		{
//			A[i] = A[i] ^ (box2[4 * i + j] << 4 * j);
//		}
//	}
//
//
//	//return rez;
//
//}
//
//void Block64::L()
//{
//
//	int i = 0, j = 0;
//	unsigned __int16 tmp = 0;
//
//	for (i = 0; i<4; i++)
//	{
//		tmp = 0;
//		for (j = 0; j<16; j++)
//		{
//			if (getbit(A[i], j) == 1)
//			{
//				tmp = tmp^L1[j];
//			}
//		}
//		A[i] = tmp;
//	}
//
//}
//
//void Block64::S()
//{
//	//Block64 rez;
//
//
//	int i = 0, j = 0, bl[4][4], box[16], box2[16];
//
//	for (i = 0; i<4; i++)
//	{
//		for (j = 0; j<4; j++)
//		{
//			bl[i][j] = (A[i] >> 4 * j) & 0xf;
//			box[4 * i + j] = bl[i][j];
//		}
//	}
//
//
//
//
//	//��������� ������������
//	for (i = 0; i<16; i++)
//	{
//		box2[i] = pi[box[i]];
//	}
//
//
//
//	//rez.Clear();
//
//
//
//	for (i = 0; i<4; i++)
//	{
//		A[i] = 0;
//		for (j = 0; j<4; j++)
//		{
//			A[i] = A[i] ^ (box2[4 * i + j] << 4 * j);
//		}
//	}
//
//
//	//return rez;
//
//}
//
//unsigned int Block64::wtMatr()
//{
//	int i = 0, ch = 0;
//
//	for (i = 0; i<4; i++)
//	{
//		if (A[i] != 0) ch++;
//	}
//
//	return ch;
//
//}
//
//unsigned int Block64::r()
//{
//	unsigned int rez = 0, one = 1;
//
//	int i = 0, j = 0, bl[4][4], box[16];
//
//	for (i = 0; i<4; i++)
//	{
//		for (j = 0; j<4; j++)
//		{
//			bl[i][j] = (A[i] >> 4 * j) & 0xf;
//			box[4 * i + j] = bl[i][j];
//		}
//	}
//
//	for (i = 0; i<16; i++)
//	{
//		if (box[i] != 0)
//		{
//			rez = rez ^ (one << i);
//		}
//	}
//
//	return rez;
//}
//
//bool Block64::IsSoglas(Block64 y)
//{
//
//	int i = 0, j = 0, bl[4][4], blY[4][4], box[16], boxY[16];
//	int razflag = 0;
//
//	for (i = 0; i<4; i++)
//	{
//		for (j = 0; j<4; j++)
//		{
//			bl[i][j] = (A[i] >> 4 * j) & 0xf;
//			box[4 * i + j] = bl[i][j];
//
//			blY[i][j] = (y.A[i] >> 4 * j) & 0xf;
//			boxY[4 * i + j] = blY[i][j];
//		}
//	}
//
//	for (i = 0; i<16; i++)
//	{
//		if (raz[box[i]][boxY[i]] == 0)
//		{
//			//razflag++;
//			return false;
//		}
//	}
//
//	//if (razflag==16) return true;
//	//else return false;
//
//	return true;
//
//}
//
//Block64 Block64::operator^(Block64 v__)
//{
//	Block64 rez;
//
//	rez.A[0] = A[0] ^ v__.A[0];
//	rez.A[1] = A[1] ^ v__.A[1];
//	rez.A[2] = A[2] ^ v__.A[2];
//	rez.A[3] = A[3] ^ v__.A[3];
//
//
//	return rez;
//}
//
//Block64 Block64::operator=(Block64 v__)
//{
//	A[0] = v__.A[0];
//	A[1] = v__.A[1];
//	A[2] = v__.A[2];
//	A[3] = v__.A[3];
//
//	return *this;
//}
